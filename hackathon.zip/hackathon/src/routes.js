import React, { Component } from "react";
import logo from './logo.svg';
import './App.css';
import { Router, Switch, Route } from "react-router-dom";
import PrimarySearchAppBar from './components/Navbar'
import SignIn from './components/login'
import Home from './components/Home'
import Contact from './components/Contact'
import history from './components/history'
import SignUp from './components/Register'
import PersistentDrawerLeft from './components/AdminScreen'
import CustomizedTables from './components/CrowdFunding'
import Photos from './components/photos'
export default function Routes() {
  return (
    <div>
      <Router history={history}>
        <Switch>
          <Route path="/" exact component={SignIn} />
          <Route path="/SignIn"  component={SignIn} />
          <Route path="/SignUp"  component={SignUp} />
          <Route path="/contact" component={Contact} />
          <Route path="/admin" component={PersistentDrawerLeft} />
          <Route path="/crowdfunding" component={CustomizedTables} />
          <Route path="/photos"  component={Photos} />
        </Switch>
      </Router>
    </div>
  );
}