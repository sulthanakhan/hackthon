import React from 'react';
import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Switch, Route } from "react-router-dom";
import PrimarySearchAppBar from './components/Navbar'
import SignIn from './components/login'
import Home from './components/Home'
import Contact from './components/Contact'
import history from './components/history'
import Routes from './routes'
function App() {
  return (
    <div>
      <PrimarySearchAppBar />
    </div>
  );
}

export default App;
