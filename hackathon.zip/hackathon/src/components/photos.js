import React from 'react';
import Coverflow from 'react-coverflow'
import Typography from '@material-ui/core/Typography';
import alumni from '../assets/alumni.jpg'
import grad from '../assets/grad.jpg'
import graduation from '../assets/graduation.jpg'
import jobfair from '../assets/jobfair.jpg'
import g from '../assets/g.jpg'
import images from '../assets/images.jpg'
import special from '../assets/special.jpg'
export default function Photo() {
    var fn = function () {
        /* do you want */  
      }
    return (
        <div>


<Typography variant="h5" noWrap>
           Gladiator Alumni Events
          </Typography>
            <Coverflow
    width={960}
    height={600}
    displayQuantityOfSide={2}
    navigation={false}
    enableHeading={false}
  >
    <div
      onClick={() => fn()}
      onKeyDown={() => fn()}
      role="menuitem"
      tabIndex="0"
    >
      <img
        src={grad}
        alt='title or description'
        style={{ display: 'block', width: '100%' }}
      />
    </div>
    <img src={alumni} alt='title or description' />
    <img src={graduation} alt='title or description' />
    <img src={jobfair} alt='title or description'/>
    <img src={g} alt='title or description' />
    <img src={images} alt='title or description' />
    <img src={special} alt='title or description' />
  </Coverflow>, 

        </div>
    );
}