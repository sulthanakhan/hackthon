import React from 'react';
import Coverflow from 'react-coverflow'
import alumni from '../assets/alumni.jpg'
import grad from '../assets/grad.jpg'
import graduation from '../assets/graduation.jpg'
import jobfair from '../assets/jobfair.jpg'
import Typography from '@material-ui/core/Typography';
export default function Contact() {
    
    return (
        <div>
        
        <Typography  variant="h4" noWrap style={{textAlign: 'center'}}>
            Contact us at 1800 000 1111
          </Typography>

          <Typography  variant="h4" noWrap style={{textAlign: 'center'}}>
            helpline@infosys.com
          </Typography>

        </div>
    );
}