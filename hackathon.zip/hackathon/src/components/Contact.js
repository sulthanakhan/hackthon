import React from 'react';
import Coverflow from 'react-coverflow'
import alumni from '../assets/alumni.jpg'
import grad from '../assets/grad.jpg'
import graduation from '../assets/graduation.jpg'
import jobfair from '../assets/jobfair.jpg'
export default function Contact() {
    
    return (
        <div>
        

        </div>
    );
}