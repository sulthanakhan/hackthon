import React from 'react';
import { withStyles, makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import { TableSortLabel } from '@material-ui/core';
import Typography from '@material-ui/core/Typography';
const StyledTableCell = withStyles((theme) => ({
    TableContainer: {
        paddingTop:200,
    },
    head: {
        backgroundColor: theme.palette.text.primary,
        color: theme.palette.common.white,
    },
    body: {
        
        fontSize: 14,
    },
}))(TableCell);

const StyledTableRow = withStyles((theme) => ({
    root: {
        '&:nth-of-type(odd)': {
            backgroundColor: theme.palette.action.hover,
        },
    },
}))(TableRow);

function createData( type,desc,date,id) {
    return { type,desc,date,id };
}

const rows = [
    createData( 'AlumniMeet','AlumniMeet','24/07/2020','1'),
    createData( 'Job fair','Job fair','04/05/2019','2'),
    createData( 'Notebooks Distribution','Notebooks Distribution','09/04/2018','3'),
    createData( 'Certificates','Certificates','14/03/2017','4'),
    createData( 'Job fair','Job fair','25/01/2015','5'),
];

const useStyles = makeStyles({
    table: {
      minWidth: 500,
    },
});

export default function Events() {
    const classes = useStyles();

    return (

        <div>
            <Typography className={classes.title} variant="h4" noWrap style={{textAlign: 'center'}}>
            Events
          </Typography>
          <TableContainer component={Paper}>
      <Table className={classes.table} aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell>Event Type</TableCell>
            <TableCell align="right">Event Description</TableCell>
            <TableCell align="right">Event Date</TableCell>
            
            <TableCell align="right">Event Id</TableCell>
           
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row) => (
            <TableRow key={row.type}>
              <TableCell component="th" scope="row">
                {row.type}
              </TableCell>
              <TableCell align="right">{row.desc}</TableCell>
              <TableCell align="right">{row.date}</TableCell>
              <TableCell align="right">{row.id}</TableCell>
              
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
        </div>
    );
}
