import React from 'react';
import { withStyles, makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import { TableSortLabel } from '@material-ui/core';
import Typography from '@material-ui/core/Typography';
const StyledTableCell = withStyles((theme) => ({
    TableContainer: {
        paddingTop:200,
    },
    head: {
        backgroundColor: theme.palette.common.black,
        color: theme.palette.common.white,
    },
    body: {
        
        fontSize: 14,
    },
}))(TableCell);

const StyledTableRow = withStyles((theme) => ({
    root: {
        '&:nth-of-type(odd)': {
            backgroundColor: theme.palette.action.hover,
        },
    },
}))(TableRow);

function createData(name, amount, eventname,date) {
    return { name, amount, eventname,date };
}

const rows = [
    createData('Andrew', 1000, 'AlumniMeet','24/07/2020'),
    createData('Jonas', 2000, 'Job fair','04/05/2019'),
    createData('Eclair', 500, 'Notebooks Distribution','09/04/2018'),
    createData('Stiffen', 3000, 'Certificates','14/03/2017'),
    createData('Rose', 2000, 'Job fair','25/01/2015'),
];

const useStyles = makeStyles({
    table: {
      minWidth: 500,
    },
});

export default function CustomizedTables() {
    const classes = useStyles();

    return (

        <div>
           <Typography className={classes.title} variant="h6" noWrap>
           Account Number:055801680549
          </Typography>
          <Typography className={classes.title} variant="h6" noWrap>
           IFSC Code:ICICI80549
          </Typography>
            <TableContainer component={Paper}>
                <Table className={classes.table} aria-label="customized table">
                    <TableHead>
                        <TableRow>
                            <StyledTableCell>Student Name</StyledTableCell>
                            <StyledTableCell align="right">Amount</StyledTableCell>
                            <StyledTableCell align="right">Event Name</StyledTableCell>
                            <StyledTableCell align="right">Event Date</StyledTableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {rows.map((row) => (
                            <StyledTableRow key={row.name}>
                                <StyledTableCell component="th" scope="row">
                                    {row.name}
                                </StyledTableCell>
                                <StyledTableCell align="right">{row.amount}</StyledTableCell>
                                <StyledTableCell align="right">{row.eventname}</StyledTableCell>
                                <StyledTableCell align="right">{row.date}</StyledTableCell>
                            </StyledTableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
        </div>
    );
}
