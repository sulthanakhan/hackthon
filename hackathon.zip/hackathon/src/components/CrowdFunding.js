import React from 'react';
import { withStyles, makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import { TableSortLabel } from '@material-ui/core';
import Typography from '@material-ui/core/Typography';
const StyledTableCell = withStyles((theme) => ({
    TableContainer: {
        paddingTop:200,
    },
    head: {
        backgroundColor: theme.palette.text.primary,
        color: theme.palette.common.white,
    },
    body: {
        
        fontSize: 14,
    },
}))(TableCell);

const StyledTableRow = withStyles((theme) => ({
    root: {
        '&:nth-of-type(odd)': {
            backgroundColor: theme.palette.action.hover,
        },
    },
}))(TableRow);

function createData( eventname,date,name,amount,transaction) {
    return { eventname,date,name,amount,transaction };
}

const rows = [
    createData( 'AlumniMeet','24/07/2020','Andrew', 1000,'24/07/2020'),
    createData( 'Job fair','04/05/2019','Jonas', 2000,'04/05/2019'),
    createData( 'Notebooks Distribution','09/04/2018','Eclair', 500,'09/04/2018'),
    createData( 'Certificates','14/03/2017','Stiffen', 3000,'14/03/2017'),
    createData( 'Job fair','25/01/2015','Rose', 2000,'25/01/2015'),
];

const useStyles = makeStyles({
    table: {
      minWidth: 500,
    },
});

export default function CustomizedTables() {
    const classes = useStyles();

    return (

        <div>
            <Typography className={classes.title} variant="h4" noWrap style={{textAlign: 'center'}}>
            Crowd Funding
          </Typography>

           <Typography className={classes.title} variant="h6" noWrap>
           Account Number:055801680549
          </Typography>
          <Typography className={classes.title} variant="h6" noWrap>
           IFSC Code:ICICI80549
          </Typography>
          <TableContainer component={Paper}>
      <Table className={classes.table} aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell>Event Name</TableCell>
            <TableCell align="right">Event Date</TableCell>
            <TableCell align="right">Student Name</TableCell>
            <TableCell align="right">Amount</TableCell>
            <TableCell align="right">Transaction Date</TableCell>
           
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row) => (
            <TableRow key={row.name}>
              <TableCell component="th" scope="row">
                {row.eventname}
              </TableCell>
              <TableCell align="right">{row.date}</TableCell>
              <TableCell align="right">{row.name}</TableCell>
              <TableCell align="right">{row.amount}</TableCell>
              <TableCell align="right">{row.transaction}</TableCell>
              
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
        </div>
    );
}
