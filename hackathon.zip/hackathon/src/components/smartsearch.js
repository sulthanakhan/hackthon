import React from 'react';
import { makeStyles, fade } from '@material-ui/core/styles';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import InputBase from '@material-ui/core/InputBase';
import SearchIcon from '@material-ui/icons/Search';
import TextField from '@material-ui/core/TextField';
import  Table from 'react-bootstrap/Table'
import Button from '@material-ui/core/Button';
const useStyles = makeStyles((theme) => ({
    formControl: {
        margin: theme.spacing(1),
        minWidth: 120,
    },
    selectEmpty: {
        marginTop: theme.spacing(2),
    },
    search: {
        position: 'relative',
        borderRadius: theme.shape.borderRadius,
        backgroundColor: fade(theme.palette.common.white, 0.15),
        '&:hover': {
            backgroundColor: fade(theme.palette.common.white, 0.25),
        },
        marginRight: theme.spacing(2),
        marginLeft: 0,
        width: '100%',
        [theme.breakpoints.up('sm')]: {
            marginLeft: theme.spacing(3),
            width: 'auto',
        },
    },
    searchIcon: {
        padding: theme.spacing(0, 2),
        height: '100%',
        position: 'absolute',
        pointerEvents: 'none',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
    },
    root: {
        '& > *': {
            margin: theme.spacing(1),
            width: '25ch',
        },
    },
}));

export default function SimpleSelect() {
    const classes = useStyles();
    const [event, setEvent] = React.useState('');
    const [tab,settab] = React.useState(false)
    const handleChange = (event) => {
        setEvent(event.target.value);
    };
    const data = [
        {
            "EventName": "AlumniMeet",
            "CollegeName": "Canadore College",
            "EventDate": "24/05/2000",
            "contactnumber": "907896321",
            "collegeid": 1
        },
        {
            "EventName": "Job Fair",
            "CollegeName": "Humber College",
            "EventDate": "24/05/2009",
            "contactnumber": 912354678,
            "collegeid": 2
        },
        {
            "EventName": "NoteBook Distribution",
            "CollegeName": "LPU College",
            "EventDate": "24/05/2000",
            "contactnumber": "963258741",
            "collegeid": 3
        },
        {
            "EventName": "Blood Camp",
            "CollegeName": "Canadore College",
            "EventDate": "24/05/2010",
            "contactnumber": "901250000",
            "collegeid": 4
        },
        {
            "EventName": "AlumniMeet",
            "CollegeName": "humber College",
            "EventDate": "24/05/2012",
            "contactnumber": "92300000",
            "collegeid": 5
        },
        {
            "EventName": "AlumniMeet",
            "CollegeName": "Canadore College",
            "EventDate": "24/05/2000",
            "contactnumber": "900045650",
            "collegeid": 6
        },
        {
            "EventName": "AlumniMeet",
            "CollegeName": "Canadore College",
            "EventDate": "24/05/2000",
            "contactnumber": "900000000",
            "collegeid": 6
        },
        {
            "EventName": "AlumniMeet",
            "CollegeName": "Canadore College",
            "EventDate": "24/05/2000",
            "contactnumber": "900000000",
            "collegeid": 6
        },
        {
            "EventName": "AlumniMeet",
            "CollegeName": "Canadore College",
            "EventDate": "24/05/2000",
            "contactnumber": "900000000",
            "collegeid": 6
        },
        {
            "EventName": "AlumniMeet",
            "CollegeName": "Canadore College",
            "EventDate": "24/05/2000",
            "contactnumber": "900000000",
            "collegeid": 6
        },
        {
            "EventName": "AlumniMeet",
            "CollegeName": "Canadore College",
            "EventDate": "24/05/2000",
            "contactnumber": "900000000",
            "collegeid": 6
        },
        {
            "EventName": "AlumniMeet",
            "CollegeName": "Canadore College",
            "EventDate": "24/05/2000",
            "contactnumber": "900000000",
            "collegeid": 6
        },
        {
            "EventName": "AlumniMeet",
            "CollegeName": "Canadore College",
            "EventDate": "24/05/2000",
            "contactnumber": "900000000",
            "collegeid": 6
        },
        {
            "EventName": "AlumniMeet",
            "CollegeName": "Canadore College",
            "EventDate": "24/05/2000",
            "contactnumber": "900000000",
            "collegeid": 6
        },
        {
            "EventName": "AlumniMeet",
            "CollegeName": "Canadore College",
            "EventDate": "24/05/2000",
            "contactnumber": "900000000",
            "collegeid": 6
        },
        {
            "EventName": "AlumniMeet",
            "CollegeName": "Canadore College",
            "EventDate": "24/05/2000",
            "contactnumber": "900000000",
            "collegeid": 6
        },
        {
            "EventName": "AlumniMeet",
            "CollegeName": "Canadore College",
            "EventDate": "24/05/2000",
            "contactnumber": "900000000",
            "collegeid": 6
        },
        {
            "EventName": "AlumniMeet",
            "CollegeName": "Canadore College",
            "EventDate": "24/05/2000",
            "contactnumber": "900000000",
            "collegeid": 6
        },
        {
            "EventName": "AlumniMeet",
            "CollegeName": "Canadore College",
            "EventDate": "24/05/2000",
            "contactnumber": "900000000",
            "collegeid": 6
        },
        {
            "EventName": "AlumniMeet",
            "CollegeName": "Canadore College",
            "EventDate": "24/05/2000",
            "contactnumber": "900000000",
            "collegeid": 6
        },
        {
            "EventName": "AlumniMeet",
            "CollegeName": "Canadore College",
            "EventDate": "24/05/2000",
            "contactnumber": "900000000",
            "collegeid": 6
        }]
 
   if(tab) {
    var t = <div>
        <Table striped bordered hover>
        <thead>
            <tr>
            <th>EventName</th>&nbsp;&nbsp;
            <th>EventDate</th>&nbsp;&nbsp;
            <th>College Name</th>&nbsp;&nbsp;
            <th>College Id</th>&nbsp;&nbsp;
            <th>Contact Number</th>&nbsp;&nbsp;
            </tr><br/>
        </thead>
        <tbody>
            <tr>
                <td>{data[Math.floor(Math.random() * 15)]['EventName']}</td>&nbsp;&nbsp;
                <td>{data[Math.floor(Math.random() * 15)]['EventDate']}</td>&nbsp;&nbsp;
                <td>{data[Math.floor(Math.random() * 15)]['CollegeName']}</td>&nbsp;&nbsp;
                <td>{data[Math.floor(Math.random() * 15)]['collegeid']}</td>&nbsp;&nbsp;
                <td>{data[Math.floor(Math.random() * 15)]['contactnumber']}</td>&nbsp;&nbsp;
            </tr><br/>
            <tr>
                <td>{data[Math.floor(Math.random() * 15)]['EventName']}</td>&nbsp;&nbsp;
                <td>{data[Math.floor(Math.random() * 15)]['EventDate']}</td>&nbsp;&nbsp;
                <td>{data[Math.floor(Math.random() * 15)]['CollegeName']}</td>&nbsp;&nbsp;
                <td>{data[Math.floor(Math.random() * 15)]['collegeid']}</td>&nbsp;&nbsp;
                <td>{data[Math.floor(Math.random() * 15)]['contactnumber']}</td>&nbsp;&nbsp;
            </tr><br/>
            <tr>
                <td>{data[Math.floor(Math.random() * 15)]['EventName']}</td>&nbsp;&nbsp;
                <td>{data[Math.floor(Math.random() * 15)]['EventDate']}</td>&nbsp;&nbsp;
                <td>{data[Math.floor(Math.random() * 15)]['CollegeName']}</td>&nbsp;&nbsp;
                <td>{data[Math.floor(Math.random() * 15)]['collegeid']}</td>&nbsp;&nbsp;
                <td>{data[Math.floor(Math.random() * 15)]['contactnumber']}</td>&nbsp;&nbsp;
            </tr><br/>
            <tr>
                <td>{data[Math.floor(Math.random() * 15)]['EventName']}</td>&nbsp;&nbsp;
                <td>{data[Math.floor(Math.random() * 15)]['EventDate']}</td>&nbsp;&nbsp;
                <td>{data[Math.floor(Math.random() * 15)]['CollegeName']}</td>&nbsp;&nbsp;
                <td>{data[Math.floor(Math.random() * 15)]['collegeid']}</td>&nbsp;&nbsp;
                <td>{data[Math.floor(Math.random() * 15)]['contactnumber']}</td>&nbsp;&nbsp;
            </tr>
        </tbody>
    </Table>
</div>
   }

    return (
        <div>
            <FormControl className={classes.formControl}>
                <InputLabel id="demo-simple-select-label">Smart Search</InputLabel>
                <Select
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    value={event}
                    onChange={handleChange}
                >
                    <MenuItem value="collegeid">College Id</MenuItem>
                    <MenuItem value="collegename">College Name</MenuItem>
                    <MenuItem value="batch">Batch</MenuItem>
                    <MenuItem value="eventtype">Event Type</MenuItem>
                    <MenuItem value="stream">Stream</MenuItem>
                </Select>
                <form className={classes.root} noValidate autoComplete="off">
                    <TextField id="standard-basic" label="Standard" placeholder="search" />
                </form>

                <Button onClick={() => settab({tab:true})}>Search</Button>
               
            </FormControl>
            {t}
        </div>
    );
}