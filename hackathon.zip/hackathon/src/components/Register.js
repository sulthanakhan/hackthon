import React, { useState } from 'react';
import Avatar from '@material-ui/core/Avatar';
import Button from '@material-ui/core/Button';
import CssBaseline from '@material-ui/core/CssBaseline';
import TextField from '@material-ui/core/TextField';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import Link from '@material-ui/core/Link';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';
import { TextareaAutosize } from '@material-ui/core';
import DropDownMenu from 'material-ui/DropDownMenu';
import axios from "axios"
import FormControl from '@material-ui/core/FormControl'
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import Select from '@material-ui/core/Select';
import history from './history'
const useStyles = makeStyles((theme) => ({
    paper: {
        marginTop: theme.spacing(8),
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
    },
    avatar: {
        margin: theme.spacing(1),
        backgroundColor: theme.palette.secondary.main,
    },
    form: {
        width: '100%', // Fix IE 11 issue.
        marginTop: theme.spacing(1),
    },
    submit: {
        margin: theme.spacing(3, 0, 2),
    },
    formControl: {
        margin: theme.spacing(1),
        minWidth: 120,
    },
    selectEmpty: {
        marginTop: theme.spacing(2),
    }
}));

export default function SignUp() {
    const classes = useStyles();
    const [credentials, user] = useState({
        email: '', contactnumber: '', secondarycontactnumber: '',
        currentaddress: '', rollnumber: '', dob: '', gender: '', academicdegree: '', major: '', passoutbatch: '', gender: '',
        passoutyear: '', passoutmonth: '', techprof: '', password: '', collegeid: ''
    })
    const [college,setcol] = useState()
    const [state, setState] = useState({
        chatservice: 'no',
        whatsappservice: 'yes',
        smartmatchservice: 'yes',
        eventservice: 'yes',
        newsletters: 'no',
        all: 'yes'
    });

    function usersubmit(e) {
        e.preventDefault();

        let postData = {
            ...credentials,
            preferences: state
        }
        console.log(postData)
        axios.post('localhost:9992/student/registration', postData)
            .then(function (response) {
                console.log(response);
                history.push("/SignIn")
            })
            .catch(function (error) {
                console.log(error);
            });
    }
    const handleChange = (event) => {
        setState({ ...state, [event.target.name]: event.target.checked ? 'yes' : 'no' });
    };

    return (
        <Container component="main" maxWidth="xs">
            <CssBaseline />
            <div className={classes.paper}>
                <Avatar className={classes.avatar}>
                    <LockOutlinedIcon />
                </Avatar>
                <Typography component="h1" variant="h5">
                    Sign Up
        </Typography>
                <form className={classes.form} onSubmit={usersubmit.bind(this)} >
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="email"
                        label="Email Address"
                        name="email"
                        autoComplete="email"
                        autoFocus
                        onChange={e => user({ ...credentials, email: e.target.value })}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="name"
                        label="Student Name"
                        name="name"
                        autoComplete="name"

                        onChange={e => user({ ...credentials, name: e.target.value })}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="contactnumber"
                        label="Contact Number"
                        name="contactnumber"
                        autoComplete="contactnumber"

                        onChange={e => user({ ...credentials, contactnumber: e.target.value })}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="secondarycontactnumber"
                        label="secondary Contact Number"
                        name="secondarycontactnumber"
                        autoComplete="secondarycontactnumber"

                        onChange={e => user({ ...credentials, secondarycontactnumber: e.target.value })}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="rollnumber"
                        label="Regd Number"
                        name="rollnumber"
                        autoComplete="rollnumber"

                        onChange={e => user({ ...credentials, rollnumber: e.target.value })}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="gender"
                        label="gender"
                        name="gender"
                        autoComplete="gender"

                        onChange={e => user({ ...credentials, gender: e.target.value })}
                    />
                    <FormControl className={classes.formControl} fullWidth>
                        <InputLabel id="demo-simple-select-label">College Name</InputLabel>
                        <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            value={college}
                            onChange={e => user({ ...credentials, collegeid: e.target.value },{...college, college:e.target.name})}
                            fullWidth
                        >
                            <MenuItem value={1} name="StandFord University">StandFord University</MenuItem>
                            <MenuItem value={2} name="Canadore College">Canadore College</MenuItem>
                            <MenuItem value={3} name="Humber University">Humber University</MenuItem>
                        </Select>
                    </FormControl>
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="academicdegree"
                        label="Academic Degree"
                        name="academicdegree"
                        autoComplete="academicdegree"

                        onChange={e => user({ ...credentials, academicdegree: e.target.value })}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="major"
                        label="Stream"
                        name="major"
                        autoComplete="major"

                        onChange={e => user({ ...credentials, major: e.target.value })}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="passoutbatch"
                        label="Passed Out Batch"
                        name="passoutbatch"
                        autoComplete="passoutbatch"

                        onChange={e => user({ ...credentials, passoutbatch: e.target.value })}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="passoutyear"
                        label="Passed Out Year"
                        type="number"
                        name="passoutyear"
                        autoComplete="passoutyear"

                        onChange={e => user({ ...credentials, passoutyear: parseInt(e.target.value) })}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="passoutmonth"
                        label="Passed out Month"
                        name="passoutmonth"
                        autoComplete="passoutmonth"

                        onChange={e => user({ ...credentials, passoutmonth: e.target.value })}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="techprof"
                        label="Technical Skills"
                        name="techprof"
                        autoComplete="techprof"

                        onChange={e => user({ ...credentials, techprof: e.target.value })}
                    />
                    <TextField
                        id="dob"
                        label="Birthday"
                        type="date"
                        fullWidth
                        required
                        name="dob"
                        onChange={e => user({ ...credentials, dob: e.target.value })}
                        defaultValue="2017-05-24"
                        className={classes.textField}
                        InputLabelProps={{
                            shrink: true,
                        }}
                    />
                    <p>Contact Adress</p>
                    <TextareaAutosize

                        required
                        label="Contact Adress"
                        aria-label="maximum height"
                        placeholder="Current Address"
                        defaultValue=""
                        minWidth="3"
                        name="currentaddress"
                        id="currentaddress"
                        onChange={e => user({ ...credentials, currentaddress: e.target.value })}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        name="password"
                        label="Password"
                        type="password"
                        id="password"
                        autoComplete="current-password"
                        onChange={e => user({ ...credentials, password: e.target.value })}
                    />
                    <FormControlLabel
                        control={
                            <Checkbox
                                checked={state.chatservices}
                                onChange={handleChange}
                                name="chatservice"
                                color="primary"
                            />
                        }
                        label="Chat Services"
                    />
                    <FormControlLabel
                        control={
                            <Checkbox
                                checked={state.events}
                                onChange={handleChange}
                                name="whatsappservices"
                                color="primary"
                            />
                        }
                        label="whatsappservices"
                    />
                    <FormControlLabel
                        control={
                            <Checkbox
                                checked={state.helpline}
                                onChange={handleChange}
                                name="smartmatchservice"
                                color="primary"
                            />
                        }
                        label="smartmatchservices"
                    />
                    <FormControlLabel
                        control={
                            <Checkbox
                                checked={state.photogallery}
                                onChange={handleChange}
                                name="eventservice"
                                color="primary"
                            />
                        }
                        label="Event service"
                    />
                    <FormControlLabel
                        control={
                            <Checkbox
                                checked={state.photogallery}
                                onChange={handleChange}
                                name="newsletters"
                                color="primary"
                            />
                        }
                        label="newsletters"
                    />
                    <FormControlLabel
                        control={
                            <Checkbox
                                checked={state.photogallery}
                                onChange={handleChange}
                                name="all"
                                color="primary"
                            />
                        }
                        label="all"
                    />
                    <Button
                        type="submit"
                        fullWidth
                        variant="contained"
                        color="primary"
                        className={classes.submit}

                    >
                        Sign Up
                    </Button>
                    <Grid container>
                        <Grid item>
                            <Link href="/SignIn" variant="body2">
                                {"Already have an accoount? Sign In"}
                            </Link>
                        </Grid>
                    </Grid>
                </form>
            </div>
            <Box mt={8}>

            </Box>
        </Container>
    );
}